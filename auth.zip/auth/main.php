<?php 
require_once("inc/config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <title>Categories</title>
</head>
<body>
    <main>
        <div class="list">
        <form action="action.php" method="post" class="list">
            <?php
                session_start();
                if(isset($_SESSION['user'])){
                    $db = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB);
                        if($db->connect_errno){
                            echo "Something wrong";
                            exit;
                        }else{         
                            function tree($id = 0){
                                $query = $GLOBALS['db']->query("SELECT * FROM categories WHERE parent_id = ".$id);
                                while($result = $query->fetch_assoc()){
                                    $array[] = $result;
                                    echo "<ul><input type='checkbox' name='id[]' value='".$result['id']."'><li>".$result['title']."</li><li>".$result['cat_desc']."</li>";
                                    tree($result['id']);
                                    echo "</ul>";
                                }
                            }
                            tree();
                        }
                }else{
                    header("Location: index.php");
                }
            ?>            
                <select name="select">
                    <option value="edit">Edit</option>
                    <option value="delete">Delete</option>
                </select>
                <input type="submit" value="Submit">
            </form>
            <form action="action.php" method="post" class="add">
                <input type="text" name="title" placeholder="Title" require>
                <input type="text" name="cat_desc" placeholder="Short description" require>
                <input type="hidden" name="id" value="NULL">
                <select name="select">
                    <option value="0">Without parent</option>
                    <?php
                        $query = $db->query("SELECT * FROM categories");
                        while($result = $query->fetch_assoc()){
                            echo "<option value=".$result['id'].">".$result['title']."</option>";
                        }
                    ?>
                </select>
                <input type="submit" value="Add">
            </form>
        </div>
    </main>    
</body>
</html>