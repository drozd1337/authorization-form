<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <title>Authorization form</title>
</head>
<body>
    <main>
        <div class="list">
            <?php
            require_once("inc/config.php");
            session_start();
                if(isset($_SESSION['user']) and !empty($_POST['id'])){
                    $db = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB);
                    if($db->connect_errno){
                        echo "Something wrong";
                        exit;
                    }else{
                        if(isset($_POST['select'])){
                                $count_id = count($_POST['id']);
                                $i = 0;
                            
                            if($_POST['select'] == "delete"){
                                do{
                                $db->query("DELETE FROM categories WHERE id=".$_POST['id'][$i]);
                                $db->query("UPDATE categories SET parent_id=0 WHERE parent_id=".$_POST['id'][$i]);
                                $i++;
                                }while($i < $count_id);
                                header("Location: main.php");
                            }elseif($_POST['select'] == "edit"){
                                do{
                                    $query = $db->query("SELECT * FROM categories WHERE id=".$_POST['id'][$i]);
                                    $result = $query->fetch_array();
                                    echo "<form action='' method='post' class='action'>
                                            <label for='login'>Category ID</label></br>
                                            <input type='text' name='id' value=".$result['id']."></br>
                                            <label for='title'>Title</label></br>
                                            <input type='text' name='title' value='".$result['title']."' require></br>
                                            <label for='cat_desc'>Short description</label></br>
                                            <textarea name='cat_desc' cols='26' rows='6'>".$result['cat_desc']."</textarea></br>
                                            <label for='parent_id'>Parent id</label></br>
                                            <input type='text' name='parent_id' value=".$result['parent_id']." require></br>
                                            <input type='submit' value='Submit'>
                                        </form>";
                                    $i++;
                                }while($i < $count_id);
                            }else{
                                $stmt = $db->prepare("INSERT INTO categories (id, title, cat_desc, parent_id) VALUES (NULL, ?, ?, ?)");
                                $stmt->bind_param('ssi', $_POST['title'], $_POST['cat_desc'], $_POST['select']);
                                $stmt->execute();       
                                $stmt->close();
                                header("Location: main.php");
                            }
                        }else{
                            $stmt = $db->prepare("UPDATE categories SET title=?, cat_desc=?, parent_id=? WHERE id=?");
                            $stmt->bind_param('ssii', $_POST['title'], $_POST['cat_desc'], $_POST['parent_id'], $_POST['id']);
                            $stmt->execute();
                            $stmt->close();
                            header("Location: main.php");

                        }   
                    }
                }else{
                    header("Location: index.php");
                }

            ?>
    </div>
</main>
</body>
</html>