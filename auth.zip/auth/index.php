﻿<?php 
@require_once("inc/config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha256-pasqAKBDmFT4eHoN2ndd6lN370kFiGUFyTiUHWhU7k8=" crossorigin="anonymous"></script>
    <title>Authorization form</title>
</head>
<body>
    <main class="form-container">
        <?php
            foreach($_POST as $key => $value){
                $_POST[htmlspecialchars(stripslashes(trim($key)))] = htmlspecialchars(stripslashes(trim($value)));
            }
            if(isset($_POST['submit']) and !empty($_POST['login']) and !empty($_POST['password'])){
                @$db = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB);
                if($db->connect_errno){
                    echo "Something wrong";
                    exit;
                }else{
                    $stmt = $db->prepare("SELECT password FROM users WHERE user=?");
                    $stmt->bind_param('s', $_POST['login']);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    $hash = $result->fetch_assoc();
                    if(!password_verify($_POST['password'],$hash['password'])){
                        echo '<script type="text/javascript">alert("Incorrect username or password")</script>';
                    }else{
                        session_start();
                        $_SESSION['user'] = $_POST['login'];
                        header("Location: main.php");
                    }
                }
            }else{
                if(@$_POST['submit'] === 'Submit')
                    echo '<script type="text/javascript">alert("Please fill all fields")</script>';
            }
        ?>
        <div class="form">
            <form method="post" action="">
                <h1>Authorization form</h1>
                <label for="login">Login</label>
                <input type="text" name="login" value="admin" require></br>
                <label for="password">Password</label>
                <input type="password" name="password" value="admin" maxlenght="20" require></br>
                <input type="submit" name="submit" value="Submit">
            </form>
        </div>
    </main>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha256-pasqAKBDmFT4eHoN2ndd6lN370kFiGUFyTiUHWhU7k8=" crossorigin="anonymous"></script>
</body>
</html>